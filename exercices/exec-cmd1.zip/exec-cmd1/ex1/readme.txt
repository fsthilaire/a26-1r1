README
Ceci est un fichier d'exemple.
Ligne 0001 - contenu de remplissage.  
Ligne 0002 - contenu de remplissage.  
Ligne 0003 - contenu de remplissage.  
Ligne 0004 - contenu de remplissage.  
Ligne 0005 - contenu de remplissage.  
Ligne 0006 - contenu de remplissage.  
Ligne 0007 - contenu de remplissage.  
Ligne 0008 - contenu de remplissage.  
Ligne 0009 - contenu de remplissage.  
Ligne 0010 - contenu de remplissage.  
..........................................................
