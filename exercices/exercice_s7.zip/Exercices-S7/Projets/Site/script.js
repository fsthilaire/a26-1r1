console.log('site');
Ligne 0001 - contenu de remplissage pour l'exercice.  
Ligne 0002 - contenu de remplissage pour l'exercice.  
Ligne 0003 - contenu de remplissage pour l'exercice.  
Ligne 0004 - contenu de remplissage pour l'exercice.  
Ligne 0005 - contenu de remplissage pour l'exercice.  
Ligne 0006 - contenu de remplissage pour l'exercice.  
Ligne 0007 - contenu de remplissage pour l'exercice.  
Ligne 0008 - contenu de remplissage pour l'exercice.  
Ligne 0009 - contenu de remplissage pour l'exercice.  
Ligne 0010 - contenu de remplissage pour l'exercice.  
Ligne 0011 - contenu de remplissage pour l'exercice.  
Ligne 0012 - contenu de remplissage pour l'exercice.  
Ligne 0013 - contenu de remplissage pour l'exercice.  
Ligne 0014 - contenu de remplissage pour l'exercice.  
Ligne 0015 - contenu de remplissage pour l'exercice.  
Ligne 0016 - contenu de remplissage pour l'exercice.  
..............................
